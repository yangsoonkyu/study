// changeFontSize 함수를 만든다
function changeFontSize() {
    document.getElementById('demo').style.fontSize='1.5em'
}